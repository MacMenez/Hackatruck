//
//  RemedioViewApp.swift
//  RemedioView
//
//  Created by Student on 12/06/23.
//

import SwiftUI

@main
struct RemedioViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

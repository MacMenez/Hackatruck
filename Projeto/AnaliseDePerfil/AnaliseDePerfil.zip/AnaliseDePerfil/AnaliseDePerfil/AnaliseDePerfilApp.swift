//
//  AnaliseDePerfilApp.swift
//  AnaliseDePerfil
//
//  Created by Student07 on 13/06/23.
//

import SwiftUI

@main
struct AnaliseDePerfilApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  PieChartApp.swift
//  PieChart
//
//  Created by Student05 on 12/06/23.
//

import SwiftUI

@main
struct PieChartApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  graficoApp.swift
//  grafico
//
//  Created by Student07 on 15/06/23.
//

import SwiftUI

@main
struct graficoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

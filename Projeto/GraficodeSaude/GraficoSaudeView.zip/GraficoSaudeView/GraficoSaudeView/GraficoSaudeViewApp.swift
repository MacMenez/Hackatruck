//
//  GraficoSaudeViewApp.swift
//  GraficoSaudeView
//
//  Created by Student on 13/06/23.
//

import SwiftUI

@main
struct GraficoSaudeViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

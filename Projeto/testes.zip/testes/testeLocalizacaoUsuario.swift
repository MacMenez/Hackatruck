//
//  testeLocalizacaoUsuario.swift
//  testes
//
//  Created by Student05 on 25/05/23.
//

import SwiftUI

struct testeLocalizacaoUsuario: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct testeLocalizacaoUsuario_Previews: PreviewProvider {
    static var previews: some View {
        testeLocalizacaoUsuario()
    }
}

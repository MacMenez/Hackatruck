//
//  testeGraficoPizza.swift
//  testes
//
//  Created by Student05 on 30/05/23.
//

import SwiftUI

struct testeGraficoPizza: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct testeGraficoPizza_Previews: PreviewProvider {
    static var previews: some View {
        testeGraficoPizza()
    }
}

//
//  testesApp.swift
//  testes
//
//  Created by Student05 on 24/05/23.
//

import SwiftUI

@main
struct testesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

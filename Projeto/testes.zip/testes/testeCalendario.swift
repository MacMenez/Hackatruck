//
//  testeCalendario.swift
//  testes
//
//  Created by Student05 on 24/05/23.
//

import SwiftUI

struct testeCalendario: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct testeCalendario_Previews: PreviewProvider {
    static var previews: some View {
        testeCalendario()
    }
}

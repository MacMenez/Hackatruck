//
//  LumiApp.swift
//  Lumi
//
//  Created by Student03 on 07/06/23.
//

import SwiftUI

@main
struct LumiApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}

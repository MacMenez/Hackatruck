//
//  contatos.swift
//  AnaliseDePerfil
//
//  Created by Student07 on 13/06/23.
//

import Foundation

struct Contato : Identifiable
{
    var id: Int
    var nome: String
    var parentesco: String
    var telefone: String
 
}

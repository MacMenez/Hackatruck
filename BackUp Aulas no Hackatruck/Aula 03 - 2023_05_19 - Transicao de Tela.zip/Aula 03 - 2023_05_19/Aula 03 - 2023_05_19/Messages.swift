//
//  Messages.swift
//  Aula 03 - 2023_05_19
//
//  Created by Student05 on 19/05/23.
//

import SwiftUI

struct Messages: View {
    var body: some View {
        ZStack{
            Color(.black).opacity(0.6).ignoresSafeArea()
        }
    }
}

struct Messages_Previews: PreviewProvider {
    static var previews: some View {
        Messages()
    }
}

//
//  Futebol.swift
//  Aula 03 - 2023_05_19
//
//  Created by Student05 on 19/05/23.
//

import SwiftUI

struct Futebol: View {
    var body: some View {
        ZStack{
            Color.green.ignoresSafeArea()
        }
    }
}

struct Futebol_Previews: PreviewProvider {
    static var previews: some View {
        Futebol()
    }
}

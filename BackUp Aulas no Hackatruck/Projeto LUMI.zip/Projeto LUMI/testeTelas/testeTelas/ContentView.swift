//
//  ContentView.swift
//  testeTelas
//
//  Created by Student05 on 13/06/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView{
            VStack{
                ForEach(1..<20) { index in
                    HStack{
                        Text("\(index)").padding()
                        Spacer()
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

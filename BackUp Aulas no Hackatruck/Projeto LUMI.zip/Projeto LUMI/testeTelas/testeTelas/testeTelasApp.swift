//
//  testeTelasApp.swift
//  testeTelas
//
//  Created by Student05 on 13/06/23.
//

import SwiftUI

@main
struct testeTelasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

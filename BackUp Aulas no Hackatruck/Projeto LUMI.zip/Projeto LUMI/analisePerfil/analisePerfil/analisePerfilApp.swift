//
//  analisePerfilApp.swift
//  analisePerfil
//
//  Created by Student05 on 12/06/23.
//

import SwiftUI

@main
struct analisePerfilApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

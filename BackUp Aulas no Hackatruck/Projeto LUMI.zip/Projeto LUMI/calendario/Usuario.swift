//
//  Usuario.swift
//  calendario
//
//  Created by Student05 on 07/06/23.
//

import Foundation

struct paciente {
    let cpf: Int // Identificacao dentro do BD
    let name: String //Nome obtido na hora do cadastro
    
}

struct remedio {
    let id: Int //Identificacao do remedio na lista
    let nome: String // Nome do remedio
    let tempo_consumo_dia: String //Informa qual o horario que o remedio tera que ser pego - medir em horas
    let qtd_pilula_remedio: Int //Quantidade de pilulas que virao dentro da caixa do remedio quando ele for comprado
    let qtd_total: Int // Quantidade de pipulas que serao diminuidas ate ficar na hora de "renovar o estoque"
}

//
//  CorrecaoD1.swift
//  Aula 01 - 2023_05_17
//
//  Created by Student05 on 18/05/23.
//

import SwiftUI

struct CorrecaoD1: View {
    var body: some View {
        Image("bg").resizable().scaledToFit().clipShape(Circle())
    }
}

struct CorrecaoD1_Previews: PreviewProvider {
    static var previews: some View {
        CorrecaoD1()
    }
}

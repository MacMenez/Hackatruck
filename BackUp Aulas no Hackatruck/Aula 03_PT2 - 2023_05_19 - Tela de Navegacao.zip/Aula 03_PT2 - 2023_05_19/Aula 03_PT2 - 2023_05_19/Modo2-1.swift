//
//  Modo2-1.swift
//  Aula 03_PT2 - 2023_05_19
//
//  Created by Student05 on 19/05/23.
//

import SwiftUI

struct Modo2_1: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Modo2_1_Previews: PreviewProvider {
    static var previews: some View {
        Modo2_1()
    }
}

//___FILEHEADER___

import SwiftUI

@main
struct ___PACKAGENAME:App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
